Perks
======

* Coins
  - coins with value 2 start showing up
  - coins with value 3 start showing up
  - coins with value 4 start showing up
  - coins with value 5 start showing up
  
* Speed (on a power-up)
  - makes the ship go 2x as fast for 5 seconds
  - makes the ship go 2x as fast for 10 seconds
  - makes the ship go 2x as fast for 15 seconds
  - makes the ship go 2x as fast for 20 seconds
  
* Shield (on a power-up)
  - ship is protected by a shield until first asteroid hit for 5 seconds
  - ship is protected by a shield until first asteroid hit for 10 seconds
  - ship is protected by a shield until first asteroid hit for 15 seconds
  - ship is protected by a shield until first asteroid hit for 20 seconds
  - ship is protected by a shield until first asteroid hit for infinite amount of time
  
* Wormhole (on a power-up)
  - ship is transported 50 units forward or backwards
  - ship is transported 100 units forwards or backwards
  - ship is transported 500 units forwards or backwards
  - ship is transported 1000 units forwards or backwards
  - ship is only transported forwards
  
* Magnetic Field (on a power-up)
  - ship attracts coins that lasts for 5 seconds
  - ship attracts coins that lasts for 10 seconds
  - ship attracts coins that lasts for 15 seconds
  - ship attracts coins that lasts for 20 seconds
  - coins are doubled in value
  - coins are tripled in value
  
* Force Field (on a power-up)
  - field that pushes everything away for 5 seconds
  - field that pushes everything away for 10 seconds
  - field that pushes everything away for 15 seconds
  - field that pushes everything away for 20 seconds
  
* Distance (on a power-up)
  - 2x the distance multiplier
  - 3x the distance multiplier
  - 4x the distance multiplier
  - 5x the distance multiplier
  
